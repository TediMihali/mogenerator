from setuptools import setup

setup(
    name='mpgenerator',
    version='1.1.0',
    packages=[''],
    url='https://github.com/TediMihali/mpgenerator',
    license='',
    author='Tedi Mhali',
    author_email='tedimihali1@gmail.com',
    description=''
)
