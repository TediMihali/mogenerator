from setuptools import setup

setup(
    name='mpgenerator',
    version='1.0.0',
    packages=[''],
    url='',
    license='',
    author='Tedi Mhali',
    author_email='tedimihali1@gmail.com',
    description=''
)
